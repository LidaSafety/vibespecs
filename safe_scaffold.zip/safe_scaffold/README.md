# safe-scaffold

A starter codebase for the SPS Fellowship project:
**"Guaranteed-safe coding-agent scaffold: formal action gating + adversarial server-code verification."**

This is a working skeleton, not a finished system. It implements the
core loop the proposal describes — intercept agent action → check
against a formal spec → query human on uncertainty → update spec —
and a separate adversarial-test pipeline for the server-code track.

The aim is to make Day 1 of the hackathon productive: every component
described in the methodology section has a corresponding module here,
with the design rationale documented inline so you can extend each
piece without re-deriving the choices.

## Architecture

```
                ┌──────────────────────────────────────────────┐
                │              Coding agent (Claude            │
                │              Code, Cursor, aider …)          │
                └────────────────────┬─────────────────────────┘
                                     │ proposes tool call
                                     ▼
                ┌──────────────────────────────────────────────┐
                │  interceptor.py                              │
                │    parse_claude_code_hook_payload ─► Action  │
                │    wrap_envelope                             │
                └────────────────────┬─────────────────────────┘
                                     │ ActionEnvelope
                                     ▼
                ┌──────────────────────────────────────────────┐
                │  verifier.verify(action, policy)             │
                │    DSL conditions ──compile──► Z3 BoolRef    │
                │    decide ALLOW / DENY / UNKNOWN             │
                └──────┬──────────────────────────┬────────────┘
                       │ ALLOW                    │ DENY/UNKNOWN
                       ▼                          ▼
              forward to agent          ┌──────────────────────────┐
                                        │ human_loop.resolve_unknown
                                        │   prompter (terminal/UI) │
                                        │   if "allow & remember": │
                                        │     translator.translate │
                                        │       _clarification ───►│
                                        │   journal each decision  │
                                        └──────────┬───────────────┘
                                                   ▼
                                           new Policy version
```

### Track 1: action gating (formal)

| Module | Role | Maps to proposal section |
|---|---|---|
| `world_model.py` | Typed `Action` variants (shell, file r/w/d, network, signal, env) | "Defining a world model that describes the different actions" |
| `spec.py` | `Policy` = ordered list of `Rule`s with effect ∈ {allow, deny} and a JSON-DSL condition | "specifications of desired output" |
| `condition.py` | The restricted DSL the LLM emits + compiler to Z3 | bridge between NL translator and verifier |
| `verifier.py` | `verify(action, policy)` returns ALLOW/DENY/UNKNOWN; `check_policy_property` proves invariants of the *policy itself* | "leveraging existing formal methods proof systems" |
| `translator.py` | NL → Policy via an LLM that may only emit validated DSL (never code) | "describing how to turn natural language descriptions into specifications" |
| `human_loop.py` | Terminal prompter + journal + policy-update path | "the user would be prompted to block or allow the command. If they allow it, they need to provide a description … which will be used to change the underlying spec" |
| `interceptor.py` | Glues the above into a Claude Code PreToolUse hook | "integrate with an existing coding agent" |
| `cli.py` | `safe-scaffold {init-policy, hook, check, prove}` | runtime entry point |

### Track 2: server-code gating (empirical)

| Module | Role | Maps to proposal section |
|---|---|---|
| `server_verifier/spec.py` | `ServerSpec`: endpoints, auth, params, postconditions, security properties | "world model that encompasses only server processes" |
| `server_verifier/adversarial.py` | LLM red-teamer that generates pytest suites from a `ServerSpec`, few-shot-primed with OWASP exemplars | "white box test case generation by an adversarial model … given few-shot examples of security vulnerabilities" |
| `server_verifier/runner.py` | Subprocess pytest runner, returns structured `VerificationRun` with which security properties were violated | "checked through test case generation" |

## Quickstart

```bash
# 1. install
pip install -e ".[server-verifier,dev]"

# 2. inspect the Track 1 loop end-to-end with a stub LLM (no API key)
python examples/demo_track1_actions.py

# 3. inspect Track 2 generation
python examples/demo_track2_server_verification.py

# 4. run tests
pytest -q
```

Live use of the translator needs `ANTHROPIC_API_KEY`. Swap
`StubLLMClient(...)` for `AnthropicTranslatorClient()` in the demos.

### Wiring into Claude Code

```bash
# Set your enforcement policy
python -m safe_scaffold.cli init-policy /path/to/your/project \
    --out ./.safe-scaffold/policy.json

# Wire as a PreToolUse hook
mkdir -p ~/.claude/hooks
cp hooks/claude_code_pretooluse.sh ~/.claude/hooks/pretooluse.sh
chmod +x ~/.claude/hooks/pretooluse.sh
```

(Verify the hook path against the current Claude Code docs — the
adapter in `interceptor.parse_claude_code_hook_payload` is small and
the only place that needs updating if the payload shape changes.)

## Design rationale (the non-obvious choices)

These all have longer explanations in the module docstrings; this is
the index.

**Default-deny, deny-overrides.** When the policy is silent on an
action, we ask the human, not "probably fine". This is the exact
opposite of the "skip permissions" failure mode the proposal calls
out. See `spec.py`.

**LLM emits DSL, never code.** The translator's output space is
restricted to a small JSON grammar we can validate before compilation.
This makes the translation step itself auditable. See `condition.py`
+ `translator.py`.

**DSL → Z3 (not direct Python eval).** Single decision-procedure
implementation is reused by `check_policy_property`, which asks
*about the policy itself* — e.g. "is there any action matching `rm -rf /`
that this policy could allow?" That's a Z3 satisfiability query and
trivial to write; rewriting it in Python would re-implement Z3 badly.
See `verifier.check_policy_property`.

**Every rule is provenance-tagged.** A rule installed during a
clarification dialog records the action that triggered it and the
exact NL text the user typed. Decisions are journaled with both
policy versions (before/after). The audit story is intentionally
strong because, as the proposal notes, the system has to be trusted
to do less than its predecessor (Claude Code's auto-mode) while
giving you a reason to trust it more.

**Empirical, not deductive, server verification.** The proposal is
explicit that fully proving server code correct is out of scope for
the fellowship. Track 2 settles for "an LLM red-teamer can't break
the spec on this implementation" — useful evidence, not a proof —
and `AdversarialTestGenerator.rationale` makes that limitation
visible in every run.

## What's intentionally not done

Things you'll want to do during the fellowship that aren't in the
starter:

1. **Sandboxed candidate-server execution.** `runner.py` hits a URL
   the caller starts; the next iteration should fence the server with
   bubblewrap/firejail or a container, blackholing outbound network
   and giving it a tmpfs data dir. Marked TODO in `runner.py`.
2. **Policy property library.** `check_policy_property` is general,
   but there's no curated set of forbidden patterns yet. Building one
   (rm -rf /, sudo *, writes to /etc, exfil over network …) is good
   first-month research work and gives you direct ICSE-paper material.
3. **Multi-action plan checking.** Currently every action is verified
   in isolation. Some safety properties only make sense across action
   sequences (e.g. "if you read X, you may not later send Y over the
   network"). Z3 handles this; you'd encode action sequences as a
   trace and add temporal predicates. The encoding in `condition.py`
   is set up to extend that direction.
4. **More agents.** Only Claude Code's hook format has an adapter.
   Cursor, aider, Continue, Cline each get a parser function in
   `interceptor.py`; the verifier and human loop downstream are shared.
5. **Translator robustness.** Currently one retry on invalid JSON.
   Stronger versions: stage the prompt (intents → DSL per intent →
   consistency pass), and run a second LLM as policy auditor to flag
   over-broad allow rules. Both are described in
   `translator.Translator`'s docstring.
6. **Few-shot exemplar bank.** Only one exemplar per OWASP category
   in `server_verifier/adversarial.py`. Per-endpoint retrieval over
   a larger bank (the actual research contribution for Track 2) is
   the natural next step.

## File layout

```
safe_scaffold/
├── pyproject.toml
├── README.md
├── safe_scaffold/
│   ├── __init__.py
│   ├── world_model.py          # typed Action variants
│   ├── spec.py                 # Policy, Rule, Effect, Provenance
│   ├── condition.py            # DSL grammar + Z3 compiler
│   ├── verifier.py             # verify() + check_policy_property()
│   ├── translator.py           # NL→DSL via LLM with validation
│   ├── human_loop.py           # prompter, journal, policy-update loop
│   ├── interceptor.py          # Claude Code adapter, top-level coordinator
│   ├── cli.py                  # `safe-scaffold ...` entry point
│   └── server_verifier/
│       ├── __init__.py
│       ├── spec.py             # ServerSpec, Endpoint, SecurityProperty
│       ├── adversarial.py      # AdversarialTestGenerator
│       └── runner.py           # subprocess pytest runner
├── hooks/
│   └── claude_code_pretooluse.sh
├── examples/
│   ├── demo_track1_actions.py
│   └── demo_track2_server_verification.py
└── tests/
    ├── test_verifier.py
    ├── test_translator.py
    └── test_interceptor.py
```

## Citation pointers (for the eventual paper)

- Bengio et al., *Towards Guaranteed Safe AI*, 2024 — `arXiv:2405.06624`
- Hadfield-Menell et al., *The Off-Switch Game*, 2017 — `arXiv:1611.08219`
- OWASP API Security Top 10 (2023 edition) — the source of the
  baseline `SecurityProperty.owasp_defaults()` list.
