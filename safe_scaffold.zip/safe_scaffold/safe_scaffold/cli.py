"""Command-line interface for safe_scaffold.

Subcommands:

    safe-scaffold init-policy [--output FILE]
        Write the safe_default policy to FILE (default: ./policy.json).

    safe-scaffold check --policy FILE --action JSON
        Verify a single action against a policy. Exit 0=ALLOW, 1=DENY, 2=UNKNOWN.

    safe-scaffold hook --policy FILE [--journal FILE] [--interactive]
        Run as a Claude Code PreToolUse hook. Reads JSON payload on stdin,
        writes a decision JSON on stdout, exits 0/1.

    safe-scaffold prove --policy FILE --pattern NAME
        Run a Z3-backed universal-property proof. Requires the `smt` extra.

    safe-scaffold eval [--policy FILE]
        Run the built-in eval corpus against the policy. Prints metrics.

    safe-scaffold cross-check --demo cryspen
        Run the Cryspen libcrux decompress_d cross-check demo.

    safe-scaffold task-eval [--dashboard PATH] [--no-llm]
        Run the 10-task task-spec eval and print confusion matrices for
        the structured validator, positive-only baseline, and LLM-judge
        baseline. With --dashboard, also writes a self-contained HTML
        visualization to PATH.

All subcommands return non-zero on failure. Designed to compose with shell
pipes; output is JSON when `--json` is passed, human-readable otherwise.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from safe_scaffold import __version__
from safe_scaffold.adapters import parse_claude_code_hook_payload
from safe_scaffold.policy import Policy, safe_default_policy
from safe_scaffold.verifier import Decision, verify
from safe_scaffold.world import Action


def _cmd_init_policy(args: argparse.Namespace) -> int:
    out = Path(args.output)
    if out.exists() and not args.force:
        sys.stderr.write(
            f"{out} exists. Pass --force to overwrite.\n"
        )
        return 1
    safe_default_policy().save(out)
    print(f"Wrote default policy to {out}")
    return 0


def _cmd_check(args: argparse.Namespace) -> int:
    policy = Policy.load(args.policy)
    action_data = json.loads(args.action) if isinstance(args.action, str) else args.action
    action = Action.from_dict(action_data)
    verdict = verify(action, policy)
    if args.json:
        print(json.dumps({
            "decision": verdict.decision.value,
            "matched_rule_ids": [r.id for r in verdict.matched_rules],
            "explanation": verdict.explain(),
        }, indent=2))
    else:
        print(verdict.explain())
    return {
        Decision.ALLOW: 0,
        Decision.DENY: 1,
        Decision.UNKNOWN: 2,
    }[verdict.decision]


def _cmd_hook(args: argparse.Namespace) -> int:
    policy = Policy.load(args.policy)
    payload = json.loads(sys.stdin.read())
    try:
        action = parse_claude_code_hook_payload(payload)
    except Exception as exc:
        json.dump(
            {"action": "block", "reason": f"adapter error: {exc}"},
            sys.stdout,
        )
        return 1
    verdict = verify(action, policy)
    # Fail closed on UNKNOWN — the policy has no opinion, and the runtime
    # gate must not invent one. Operators extend the policy out-of-band
    # if a blocked action turns out to be benign.
    decision_to_hook = {
        Decision.ALLOW: ("approve", "policy ALLOW"),
        Decision.DENY: ("block", "policy DENY"),
        Decision.UNKNOWN: ("block", "no policy rule matched (fail-closed)"),
    }
    name, reason = decision_to_hook[verdict.decision]
    json.dump({"action": name, "reason": reason, "explanation": verdict.explain()}, sys.stdout)
    return 0 if verdict.decision is Decision.ALLOW else 1


def _cmd_prove(args: argparse.Namespace) -> int:
    try:
        from safe_scaffold.properties import (
            Z3_AVAILABLE,
            pattern_credential_env_read,
            pattern_network_exfil,
            pattern_rm_recursive_anywhere,
            pattern_write_under,
            policy_never_allows,
        )
    except Exception as exc:
        print(f"failed to import properties module: {exc}", file=sys.stderr)
        return 1

    if not Z3_AVAILABLE:
        print(
            "z3-solver is not installed. Install with "
            "`pip install safe-scaffold[smt]` to run universal-property proofs.",
            file=sys.stderr,
        )
        return 1

    policy = Policy.load(args.policy)
    patterns = {
        "rm_recursive": (pattern_rm_recursive_anywhere(), "policy never allows recursive rm"),
        "write_etc": (pattern_write_under("/etc"), "policy never allows writes under /etc"),
        "exfil": (
            pattern_network_exfil(["attacker.example", "evil.example"]),
            "policy never allows network requests to listed evil hosts",
        ),
        "credential_env": (pattern_credential_env_read(), "policy never allows credential env reads"),
    }
    if args.pattern not in patterns:
        print(
            f"unknown pattern {args.pattern!r}. Choices: {sorted(patterns)}",
            file=sys.stderr,
        )
        return 1
    pat, desc = patterns[args.pattern]
    result = policy_never_allows(policy, pat, desc)
    print(str(result))
    return 0 if result.holds else 2


def _cmd_eval(args: argparse.Namespace) -> int:
    from safe_scaffold.eval import BENIGN_CORPUS, REDTEAM_CORPUS, run_eval

    policy = Policy.load(args.policy) if args.policy else safe_default_policy()
    metrics = run_eval(policy, REDTEAM_CORPUS, BENIGN_CORPUS)
    if args.json:
        print(json.dumps({
            "block_rate": metrics.block_rate,
            "false_allow_rate": metrics.false_allow_rate,
            "false_deny_rate": metrics.false_deny_rate,
            "redteam_total": metrics.redteam_total,
            "redteam_denied": metrics.redteam_denied,
            "redteam_allowed": metrics.redteam_allowed,
            "redteam_unknown": metrics.redteam_unknown,
            "benign_total": metrics.benign_total,
            "benign_allowed": metrics.benign_allowed,
            "benign_denied": metrics.benign_denied,
            "benign_unknown": metrics.benign_unknown,
        }, indent=2))
    else:
        print(metrics.report())
    return 0 if metrics.false_allow_rate == 0.0 else 1


def _cmd_cross_check(args: argparse.Namespace) -> int:
    if args.demo != "cryspen":
        print(f"unknown demo {args.demo!r}", file=sys.stderr)
        return 1
    from safe_scaffold.cross_check.fixtures import cryspen_decompress_d_demo

    report = cryspen_decompress_d_demo()
    print(report.summary())
    # A report with disagreements is the EXPECTED outcome of this demo (the
    # bug is real); we exit 0 because the cross-check executed cleanly.
    return 0


def _cmd_task_eval(args: argparse.Namespace) -> int:
    """Run the task-spec eval across the 10-task (or 15-task extended) corpus."""
    from safe_scaffold.task_spec.baselines import (
        LLMJudge,
        PositiveTestsOnly,
        StructuredValidator,
    )
    from safe_scaffold.task_spec.eval import print_summary, run_eval

    evaluators = [StructuredValidator(), PositiveTestsOnly()]
    if not args.no_llm:
        evaluators.append(LLMJudge())
    if args.rigorous:
        # Stronger LLM baselines: nl2postcond-style + PRDJudge-style.
        from safe_scaffold.task_spec.strong_baselines import (
            NL2PostcondJudge, PRDStyleJudge,
        )
        evaluators.extend([NL2PostcondJudge(), PRDStyleJudge()])

    corpus = None
    if args.extended:
        from safe_scaffold.task_spec.corpus_data import EXTENDED_CORPUS
        corpus = list(EXTENDED_CORPUS)

    run = run_eval(evaluators=evaluators, corpus=corpus, verbose=False)
    print_summary(run)

    if args.rigorous:
        from safe_scaffold.task_spec.metrics import print_rigorous_summary
        print()
        print_rigorous_summary(run)

    if args.ablation:
        from safe_scaffold.task_spec.ablation import (
            print_ablation_summary, run_ablation,
        )
        print()
        ablation = run_ablation(verbose=False)
        print_ablation_summary(ablation)

    if args.dashboard:
        from examples.viz_eval_dashboard import render_dashboard
        out = render_dashboard(run, path=args.dashboard)
        print(f"\nDashboard written to {out}")

    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="safe-scaffold",
        description="Formal action gating and spec validation for AI coding agents.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init-policy", help="Write the default policy to a file")
    p_init.add_argument("--output", "-o", default="policy.json")
    p_init.add_argument("--force", action="store_true", help="Overwrite if exists")
    p_init.set_defaults(func=_cmd_init_policy)

    p_check = sub.add_parser("check", help="Verify one action against a policy")
    p_check.add_argument("--policy", required=True)
    p_check.add_argument("--action", required=True, help="JSON action dict")
    p_check.add_argument("--json", action="store_true")
    p_check.set_defaults(func=_cmd_check)

    p_hook = sub.add_parser("hook", help="Run as a Claude Code PreToolUse hook")
    p_hook.add_argument("--policy", required=True)
    p_hook.set_defaults(func=_cmd_hook)

    p_prove = sub.add_parser("prove", help="Prove a universal safety property via Z3")
    p_prove.add_argument("--policy", required=True)
    p_prove.add_argument(
        "--pattern",
        required=True,
        choices=["rm_recursive", "write_etc", "exfil", "credential_env"],
    )
    p_prove.set_defaults(func=_cmd_prove)

    p_eval = sub.add_parser("eval", help="Evaluate policy against the built-in corpus")
    p_eval.add_argument("--policy", help="Path to a policy (default: safe_defaults)")
    p_eval.add_argument("--json", action="store_true")
    p_eval.set_defaults(func=_cmd_eval)

    p_cc = sub.add_parser("cross-check", help="Run a cross-check demo")
    p_cc.add_argument("--demo", required=True, choices=["cryspen"])
    p_cc.set_defaults(func=_cmd_cross_check)

    p_te = sub.add_parser(
        "task-eval",
        help="Run the 10-task task-spec eval (structured vs positive-only vs LLM-judge)",
    )
    p_te.add_argument(
        "--dashboard",
        metavar="PATH",
        help="Also write the HTML dashboard to PATH",
    )
    p_te.add_argument(
        "--no-llm",
        action="store_true",
        help="Skip the LLM-judge baseline (avoids API calls)",
    )
    p_te.add_argument(
        "--extended",
        action="store_true",
        help="Use the 15-task / 60-pair extended corpus (with mutation-generated tasks)",
    )
    p_te.add_argument(
        "--rigorous",
        action="store_true",
        help="Add nl2postcond-style + PRDJudge-style baselines AND print Cohen's kappa, discriminative power, per-invariant precision/recall",
    )
    p_te.add_argument(
        "--ablation",
        action="store_true",
        help="Also run the per-invariant ablation study",
    )
    p_te.set_defaults(func=_cmd_task_eval)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
