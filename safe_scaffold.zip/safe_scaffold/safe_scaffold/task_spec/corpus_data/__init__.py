"""Aggregate corpus across all tasks."""

from safe_scaffold.task_spec.corpus_data.auto_mutants import MUTATED_TASKS
from safe_scaffold.task_spec.corpus_data.tasks_01_05 import TASKS_01_05
from safe_scaffold.task_spec.corpus_data.tasks_06_10 import TASKS_06_10

# The core hand-authored corpus (40 (spec, candidate) pairs).
CORPUS = TASKS_01_05 + TASKS_06_10

# The extended corpus, including 5 additional tasks with mutation-generated
# candidates (60 pairs total). Use this for headline FAR / kappa numbers
# where larger N gives a tighter confidence interval; use CORPUS when the
# hand-authored realism matters.
EXTENDED_CORPUS = CORPUS + MUTATED_TASKS

__all__ = ["CORPUS", "EXTENDED_CORPUS"]
